'use client';

import React, { useEffect, useState } from 'react';
import styles from '../all-evaluation/all-evaluation.module.css';

// APIから取得される1つの期・Q情報の型
type Phase = {
    phaseId: number;
    phaseNumber: number;
    name: string;
    startDate: string;
    endDate: string;
    isClosed: boolean;
};

// 親コンポーネントから渡されるコールバック関数の型
type Props = {
    onChange: (phaseId: number) => void;
};

// 期・Q選択コンポーネント
const PeriodQuarterSelector: React.FC<Props> = ({ onChange }) => {
    // すべての期・Q一覧(APIから取得したデータ)
    const [availablePhases, setAvailablePhases] = useState<Phase[]>([]);
    // 現在選択中のphaseId(初期状態は未選択)
    const [selectedPhaseId, setSelectedPhaseId] = useState<number | "">("");

    // 初回マウント時にAPIから期・Q一覧を取得する
    useEffect(() => {
        const fetchPhases = async () => {
            try {
                const response = await fetch('http://localhost:8080/api/phases');
                const apiResponse = await response.json();
                console.log('APIレスポンス:', apiResponse); 

                // ネストされている形式にも対応
                const phasesArray = Array.isArray(apiResponse) ? apiResponse : apiResponse?.phases;
                if (!phasesArray) {
                    console.error('期・Qデータが存在しません:', apiResponse);
                    return;
                }

                // スネークケース　→　キャメルケース変換
                const formattedPhases: Phase[] = phasesArray.map((p: any) => ({
                    phaseId: Number(p.phase_id),
                    phaseNumber: p.phase_number,
                    name: p.name,
                    startDate: p.start_date,
                    endDate: p.end_date,
                    isClosed: p.is_closed,
                }));
                setAvailablePhases(formattedPhases);
            }   catch (error) {
                console.error('期・Q情報の取得に失敗しました', error);
            }
        };

        fetchPhases();
    },[]);

    // ユーザーが選択肢を変更した時に呼ばれる処理
    const handlePhaseChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const selectedValue = e.target.value;
        const phaseId = Number(selectedValue);

        if (isNaN(phaseId)) {
            console.error('不正なphaseIdが選択されました:', selectedValue);
            return;
        }

        setSelectedPhaseId(phaseId);
        onChange(phaseId);   
    };

    return (
        <div className={styles.selectorContainer}>
            <select 
                id="phase-selector"
                className={styles.selector}
                value={selectedPhaseId ?? ''}
                onChange={handlePhaseChange}
            >
                <option value="" disabled>
                    期・Qを選択してください
                </option>
                {availablePhases.map((phase) => (
                    <option key={`${phase.phaseId}-${phase.name}`} value={phase.phaseId}>
                        {phase.name}
                    </option>
                ))}
            </select>
        </div>
    );
};

export default PeriodQuarterSelector;
