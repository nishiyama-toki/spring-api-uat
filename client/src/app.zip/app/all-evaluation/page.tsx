'use client';

import React, { useEffect, useState } from 'react';
import PeriodQuarterSelector from '../components/PeriodQuarterSelector';
import styles from './all-evaluation.module.css';

type EmployeeEvaluation = {
    targetId: number;
    targetName: string;
    averageSkillScore: number | null;
    averageBusinessScore: number | null;
    averageTeamScore: number | null;
    overallAverageScore: number;
    hasComment: boolean;
};

type Comment = {
    evaluatorName: string;
    comment: string;
};

const EvaluationSummaryPage: React.FC = () => {
    const [periodId, setPeriodId] = useState<number | null>(null);
    const [evaluations, setEvaluations] = useState<EmployeeEvaluation[]>([]);
    const [selectedComment, setSelectedComment] = useState<string | null>(null);
    // console.log(periodId)
    // console.log("aaaaaa")
    // モーダルとコメント管理用
    const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
    const [comments, setComments] = useState<Comment[]>([]);
    const [selectedEmployeeName, setSelectedEmployeeName] = useState<string>('');
    const [isLoadingComments, setIsLoadingComments] = useState<boolean>(false);

    useEffect(() => {
        if (!periodId || isNaN(periodId)) {
            console.warn("評価期(periodId)が未選択のためAPI呼び出しスキップ");
            return;
        }

        const fetchEvaluations = async () => {
            try {
                const response = await fetch(`http://localhost:8080/api/all_evaluations?period_id=${periodId}`);
                const data = await response.json();
                setEvaluations(data);
            }   catch (error) {
                console.error('評価データの取得に失敗:', error);
            }
        };

        fetchEvaluations();
    }, [periodId]);

    // コメント取得ボタンが押された時の関数を追加
    const handleViewComments = async (targetId: number, targetName: string) => {
        if (periodId === null) return;

        setSelectedEmployeeName(targetName);
        setIsModalOpen(true);
        setIsLoadingComments(true);

        try {
            const response = await fetch(`http://localhost:8080/api/employees/${targetId}/comments?phase_id=${periodId}`);
            const data = await response.json();
            setComments(data);
        }   catch (error) {
                console.error('コメントの取得に失敗しました', error);
                setComments([]);
        }   finally {
                setIsLoadingComments(false);
        }
    };

    return (
        <div className={styles.container}>
            {/* 見出し部分 */}
            <div className={styles.header}>
                <h2>全社員評価一覧</h2>
                <p>✖:評価対象項目外 -:未提出</p>
            </div>

            {/* 期・Q選択 */}
            <div className={styles.selectorContainer}>
                <PeriodQuarterSelector onChange={(id) => setPeriodId(id)} />
            </div>

            {/* 評価一覧 */}
            <table className={styles.table}>
                <thead>
                    <tr>
                        <th>氏名</th>
                        <th>スキル</th>
                        <th>ビジネス</th>
                        <th>チームマネジメント</th>
                        <th>評価合計平均</th>
                        <th>コメント</th>
                    </tr>
                </thead>
                <tbody>
                    {evaluations.map((e) => (
                        <tr key={e.targetId}>
                            <td>{e.targetName}</td>
                            <td>{e.averageSkillScore?.toFixed(1) ?? '-'}</td>
                            <td>{e.averageBusinessScore?.toFixed(1) ?? '-'}</td>
                            <td>{e.averageTeamScore?.toFixed(1) ?? '-'}</td>
                            <td>{e.overallAverageScore.toFixed(2)}</td>
                            <td>
                                {e.hasComment ? (
                                    <button 
                                        className={styles.button}
                                        onClick={() => 
                                            handleViewComments(e.targetId, e.targetName)
                                        }
                                    >
                                        コメントを見る
                                    </button>
                                ) : (
                                    '-'
                                )}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {/* コメントモーダル */}
            {isModalOpen && (
                <div className={styles.modalOverlay}>
                    <div className={styles.modalContent}>
                        <div className={styles.modalHeader}>
                            <h2>{selectedEmployeeName}さんへのコメント</h2>
                            <button className={styles.modalCloseButton} onClick={() => setIsModalOpen(false)}>✖</button>
                        </div>
                        <div className={styles.modalBody}>
                            {isLoadingComments ? (
                                <p>読み込み中…</p>
                            ) : comments.length > 0 ? (
                                <ul className={styles.commentList}>
                                    {comments.map((comment, index) => (
                                        <li key={index} className={styles.commentItem}>
                                            <strong className={styles.commenterName}>{comment.evaluatorName}さんより:</strong>
                                            <p className={styles.commentText}>{comment.comment}</p>
                                        </li>
                                    ))}
                                </ul>
                            ) : (
                                <p>コメントはありません。</p>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );

};

export default EvaluationSummaryPage;