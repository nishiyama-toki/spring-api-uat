'use client'

import { useState, useEffect } from 'react';
import PeriodQuarterSelector from '../components/PeriodQuarterSelector';
import { UnsubmittedTable } from './components/UnsubmittedTable';
import styles from './UnsubmittedPage.module.css';
import { PHASE_INFO } from 'next/dist/shared/lib/constants';

type UnsubmittedResponse = {
  name: string;
};

export default function UnsubmittedPage() {
    // 選択された評価期ID(phaseId)を管理
    const [selectedPhaseId, setSelectedPhaseId] = useState<number | null>(null);  // Reactの沼

    // 未提出者一覧データ
    const [unsubmittedEmployees, setUnsubmittedEmployees] = useState<UnsubmittedResponse[]>([]);

    // 評価期が選択された時に呼ばれる
    const handlePhaseSelect = (phaseId:number) => {
        console.log('選ばれた評価期ID:', phaseId);
        setSelectedPhaseId(phaseId);
    }

    // 評価期が変更された時にAPIで未提出者一覧を取得
    useEffect(() => {
        if (selectedPhaseId === null) return;

        const fetchUnsubmitted = async () => {
            try {
                const response = await fetch(`http://localhost:8080/api/unsubmitted?phase_id=${selectedPhaseId}`);
                const data = await response.json();
                console.log('未提出者APIレスポンス:', data);

                // (安全策)data.unsubmitted が存在すればそれを使い、
                // なければ data 自体を使う
                const unsubmittedList: UnsubmittedResponse[] = data.unsubmitted || data;

                setUnsubmittedEmployees(unsubmittedList);
            }   catch (error) {
                console.error('未提出者の取得に失敗しました', error);
            }
        };

        fetchUnsubmitted();
    }, [selectedPhaseId]);

    return (
        <div className={styles.container}>
            <h1 className={styles.title}>未提出者一覧</h1>

            {/* 評価期セレクター */}
            <PeriodQuarterSelector onChange={handlePhaseSelect} />

            {/* 未提出者リスト */}
            <div className={styles.listContainer}>
                {unsubmittedEmployees.length === 0 ? (
                    <p>未提出者はいません</p>
                ) : (
                    <ul className={styles.list}>
                        {unsubmittedEmployees.map((employee, index) => (
                            <li key={index} className={styles.listItem}>
                                {employee.name}
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </div>
    );
}